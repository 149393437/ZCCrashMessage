//
//  ZCAppDelegate.h
//  CarshDemo
//
//  Created by ZhangCheng on 14-5-2.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZCAppDelegate : UIResponder <UIApplicationDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
