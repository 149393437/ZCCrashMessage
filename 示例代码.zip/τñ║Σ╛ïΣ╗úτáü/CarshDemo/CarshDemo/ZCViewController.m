


//
//  ZCViewController.m
//  CarshDemo
//
//  Created by ZhangCheng on 14-5-3.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "ZCViewController.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import <CoreLocation/CoreLocation.h>
@interface ZCViewController ()

@end

@implementation ZCViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
       // Do any additional setup after loading the view.
}
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    ALAssetsLibrary *library = [[ALAssetsLibrary alloc] init];
    
    [library enumerateGroupsWithTypes:ALAssetsGroupAll usingBlock:^(ALAssetsGroup *group, BOOL *stop) {
        NSLog(@"%@", group);
        
		[group setAssetsFilter:[ALAssetsFilter allAssets]];
        
        [group enumerateAssetsUsingBlock:^(ALAsset *result, NSUInteger index, BOOL *stop) {
            //获得相片详情 包括GPS 创建时间
            
             NSDictionary* imageMetadata = [[NSMutableDictionary alloc] initWithDictionary:result.defaultRepresentation.metadata];
            
            NSLog(@"%@",imageMetadata);
            
        }];
        
		NSLog(@"名称：%@", [group valueForProperty:ALAssetsGroupPropertyName]);
        
        NSNumber* groupType = [group valueForProperty:ALAssetsGroupPropertyType];
        
		switch ([groupType unsignedIntegerValue]) {
                
			case ALAssetsGroupAlbum:
                
			{
				NSString* persistentID = [group valueForProperty:ALAssetsGroupPropertyPersistentID];
                
				if ([[persistentID substringWithRange:NSRangeFromString(@"0,8")] isEqualToString:@"00000000"])
                    
				{
                    
					NSLog(@"来自我的电脑");
                    
				}
                
				break;
                
			}
                
			case ALAssetsGroupSavedPhotos:
                
				NSLog(@"相机胶卷");
                
				break;
                
			case ALAssetsGroupPhotoStream:
                
				NSLog(@"我的照片流");
                
				break;
                
            default:
                
				break;
                
		}
     
     
    } failureBlock:nil];
    
    
    
    
    
            
      
   
//    UIImagePickerController*vc=[[UIImagePickerController alloc]init];
//    vc.delegate=self;
//    [self presentViewController:vc animated:YES completion:nil];
//
}
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    if(picker.sourceType == UIImagePickerControllerSourceTypePhotoLibrary){
        //UIImage *image= [info objectForKey:UIImagePickerControllerOriginalImage];
        
        NSURL *assetURL = [info objectForKey:UIImagePickerControllerReferenceURL];
        ALAssetsLibrary *library = [[ALAssetsLibrary alloc] init];
       
        [library assetForURL:assetURL
                 resultBlock:^(ALAsset *asset) {
                     NSDictionary* imageMetadata = [[NSMutableDictionary alloc] initWithDictionary:asset.defaultRepresentation.metadata];
                    
                NSLog(@"%@",imageMetadata);
                     //"{GPS}" Latitude Longitude DateStamp TimeStamp
                 } 
                failureBlock:nil];
        
    }
}
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{

}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
